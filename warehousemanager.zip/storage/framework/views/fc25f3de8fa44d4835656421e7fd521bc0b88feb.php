<html>
<head>
    <meta charset="utf-8">
    <title>Test</title>
</head>
<body>
    <h1>Test Page</h1>

    <p>This is the regular test page</p>
    <a href="<?php echo e(route('contact.page')); ?>">Contact Page</a>

</body>
</html><?php /**PATH C:\xampp\htdocs\warehousemanager\resources\views/test.blade.php ENDPATH**/ ?>