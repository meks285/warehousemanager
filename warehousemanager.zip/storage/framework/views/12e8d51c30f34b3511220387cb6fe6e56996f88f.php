<html>
<head>
    <meta charset="utf-8">
    <title>About</title>
</head>
<body>
    <h1>About Page</h1>

    <p>This is the regular about page. We had some hiccups but we back again Ma Negg</p>
    <a href="<?php echo e(route('test.page')); ?>">Test Page</a>

</body>
</html><?php /**PATH C:\xampp\htdocs\warehousemanager\resources\views/about.blade.php ENDPATH**/ ?>