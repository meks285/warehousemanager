
<?php $__env->startSection('warehouse-section'); ?>
<!-- BEGIN: Import JQuery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js"></script>
<!-- END: Import JQuery -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
<div class="content">
            <div class="intro-y flex flex-col sm:flex-row items-center mt-8">
                <h2 class="text-lg font-medium mr-auto">
                    Suppliers Table
                </h2>
            </div>
            <!-- BEGIN: HTML Table Data -->
            <div class="intro-y box p-5 mt-5">
                <div class="flex flex-col sm:flex-row sm:items-end xl:items-start">
                    <form class="xl:flex sm:mr-auto" id="tabulator-html-filter-form">
                                        <div class="sm:flex items-center sm:mr-4 mt-2 xl:mt-0">
                                            <input type="text" class="input w-full sm:w-full xxl:w-full mt-2 sm:mt-0 border" id="table_search" placeholder="Search by Recipient...">
                                        </div>
                                    </form>
                                    <div class="flex mt-5 sm:mt-0">
                                        <button class="button w-1/2 sm:w-auto flex items-center border text-gray-700 mr-2 dark:bg-dark-5 dark:text-gray-300" id="tabulator-print"> <i data-feather="printer" class="w-4 h-4 mr-2"></i> Print </button>
                                        <div class="dropdown w-1/2 sm:w-auto">
                                            <button class="dropdown-toggle button w-full sm:w-auto flex items-center border text-gray-700 dark:bg-dark-5 dark:text-gray-300"> <i data-feather="file-text" class="w-4 h-4 mr-2"></i> Export <i data-feather="chevron-down" class="w-4 h-4 ml-auto sm:ml-2"></i> </button>
                                            <div class="dropdown-box w-40">
                                                <div class="dropdown-box__content box dark:bg-dark-1 p-2">
                                                    <a href="javascript:;" class="flex items-center block p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md" id="tabulator-export-csv"> <i data-feather="file-text" class="w-4 h-4 mr-2"></i> Export CSV </a>
                                                    <a href="javascript:;" class="flex items-center block p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md" id="tabulator-export-json"> <i data-feather="file-text" class="w-4 h-4 mr-2"></i> Export JSON </a>
                                                    <a href="javascript:;" class="flex items-center block p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md" id="tabulator-export-xlsx"> <i data-feather="file-text" class="w-4 h-4 mr-2"></i> Export XLSX </a>
                                                    <a href="javascript:;" class="flex items-center block p-2 transition duration-300 ease-in-out bg-white dark:bg-dark-1 hover:bg-gray-200 dark:hover:bg-dark-2 rounded-md" id="tabulator-export-html"> <i data-feather="file-text" class="w-4 h-4 mr-2"></i> Export HTML </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <br />
        <div id="recipientstablediv" class="overflow-x-auto scrollbar-hidden">
        <table class="table border-separate border border-slate-400" id="recipientstable">
                        <thead>
                            <tr class="bg-red-700 dark:bg-dark-1 text-white">
                                <th class="whitespace-no-wrap">Name</th>
                                <th class="whitespace-no-wrap">Category</th>
                                <th class="whitespace-no-wrap">Location</th>
                                <th class="whitespace-no-wrap">Contact</th>
                                <th class="whitespace-no-wrap">Contact Phone</th>
                                <th class="whitespace-no-wrap">Contact Email</th>
                                <th class="whitespace-no-wrap">Address</th>
                                <th class="whitespace-no-wrap">Action</th>
                            </tr>
                        </thead>
                        <tbody>
						<?php $__currentLoopData = $recipients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recipients): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                            <td class="border-b dark:border-dark-5 font-bold"><?php echo e($recipients->name); ?></td>
                            <td class="border-b dark:border-dark-5 font-bold"><?php echo e($recipients->category); ?></td>
                            <td class="border-b dark:border-dark-5 font-bold"><?php echo e($recipients->location); ?></td>
                            <td class="border-b dark:border-dark-5 font-bold"><?php echo e($recipients->contactperson); ?></td>
                            <td class="border-b dark:border-dark-5 font-bold"><?php echo e($recipients->contactpersonemail); ?></td>
                            <td class="border-b dark:border-dark-5 font-bold"><?php echo e($recipients->contactpersonphonenumber); ?></td>
                            <td class="border-b dark:border-dark-5 font-bold"><?php echo e($recipients->address); ?></td>
                            <td class="border-b dark:border-dark-5 font-bold"><a class="button"  onclick="deleteRecipient('<?php echo e($recipients->contactpersonemail); ?>')"><i class="fa fa-trash" style="font-size:18px; color: red;"></i></a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                            
                        </tbody>
                    </table>                                
                </div>
            </div>
                            <!-- END: HTML Table Data -->
                        </div>
<script type="text/javascript">

document.getElementById("table_search").addEventListener('input',function(ev){
    var search_value = ev.target.value;
    console.log(search_value.length)
if(search_value.length == 0){
    $("#supplierstablediv").load(location.href + " #supplierstablediv");
}
else if(search_value.length >= 4){
    $("#supplierstable tbody tr").remove(); 

$.ajax({
        url:"<?php echo e(url('search-table-commodity')); ?>",
        type: "POST",
        data: {
            search_value: search_value,
        _token: '<?php echo e(csrf_token()); ?>' 
        },
        dataType : 'json',
        success: function(result){
            var trHTML = '';
            $.each(result, function (i, commodity) {
                trHTML += '<tr><td>' + commodity.brandname + '</td><td>' + commodity.awb_number + '</td><td>' + commodity.lotno + '</td><td>' + commodity.manufacturer + '</td><td>' + commodity.expirydate + '</td><td>' + commodity.quantity + '</td><td>' + commodity.quantityremaining + '</td><td>' + commodity.suppliedby + '</td><td>' + commodity.datereceived + '</td></tr>';
            });
            $('#supplierstable').append(trHTML);
        },
        error: function(result) {
        }
        });  
}
}, false)

function deleteRecipient(email){
    $.ajax({
        url:"<?php echo e(url('delete-recipient')); ?>",
        type: "POST",
        data: {
            email: email,
        _token: '<?php echo e(csrf_token()); ?>' 
        },
        dataType : 'json',
        success: function(result){
            if(result == 1){
                toastr.success('Recipient: Deleted');
                $("#recipientstablediv").load(location.href + " #recipientstablediv");
            }
            else{
                toastr.warning('Error Deleting Recipient');
            }
        }
    });  
}


<?php if(Session::has('message')): ?>
 var type = "<?php echo e(Session::get('alert-type','info')); ?>"
 switch(type){
    case 'info':
    toastr.info(" <?php echo e(Session::get('message')); ?> ");
    break;
    case 'success':
    toastr.success(" <?php echo e(Session::get('message')); ?> ");
    break;
    case 'warning':
    toastr.warning(" <?php echo e(Session::get('message')); ?> ");
    break;
    case 'error':
    toastr.error(" <?php echo e(Session::get('message')); ?> ");
    break; 
 }
 <?php endif; ?> 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('warehouse.warehouse_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\warehousemanager\resources\views/warehouse/table-recipients.blade.php ENDPATH**/ ?>