<html>
<head>
    <meta charset="utf-8">
    <title>Contact</title>
</head>
<body>
    <h1>Contact Page</h1>

    <p>Well, at this point, we might have to call it a day. But before then. I'd need y'all conacts</p>
    <a href="<?php echo e(route('about.page')); ?>">About</a>
    <section class="footer">
        <span> We at the botton</span>
    </section>
</body>
</html><?php /**PATH C:\xampp\htdocs\warehousemanager\resources\views/contact.blade.php ENDPATH**/ ?>