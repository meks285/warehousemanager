
<?php $__env->startSection('warehouse-section'); ?>
<!-- BEGIN: Import JQuery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>
<!-- END: Import JQuery -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css" />

<!-- BEGIN: Content -->
        <div class="content">
            <div class="intro-y flex items-center mt-8">
                <h2 class="text-lg font-medium mr-auto">
                    Create Product:
                </h2>
            </div>
            <div class="grid grid-cols-12 gap-6 mt-5 relative">
                <div class="intro-y col-span-12 lg:col-span-6">
                    <!-- BEGIN: Display Information -->
                    <div class="intro-y box lg:mt-5">
                        <div class="flex items-center p-5 border-b border-gray-200 dark:border-dark-5">
                            <h2 class="font-medium text-base mr-auto">
                                Product Information
                            </h2>
                        </div>
                        <div class="p-5" style="width: 67%">
                            <?php if($errors->any()): ?>
                                <div class="bg-red-500 text-white font-bold rounded-t px-4 py-2">
                                    Errors detected ...
                                </div>
                                <ul class="border border-t-0 border-red-400 rounded-b bg-red-100 px-4 py-3 text-red-700">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <?php echo e($error); ?>

                                        </li>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                            <?php endif; ?>
                        </div>                         
                        <form action="<?php echo e(route('store.saveproduct')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                        <div class="p-5">
                            <div class="grid grid-cols-12 gap-5">
                                <div class="col-span-12 xl:col-span-8">
                                    <div>
                                        <label>Product</label>
                                        <div class="mt-2 border border-dark-3 rounded">
                                            <select id="producttype" name="producttype" data-search="true" class="tail-select w-full">
                                                <option disabled selected ></option>
                                                <?php $__currentLoopData = $productmapping_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($product->producttype); ?>"><?php echo e($product->producttype); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>                                    
                                    <div class="mt-4">
                                        <label>Manufacturer</label>
                                        <div class="mt-2 border border-dark-3 rounded form-group">
                                            <select id="manufacturer" name="manufacturer" class="form-control w-full rounded" style="height: 40px; display: inline-block;">
                                            </select>
                                        </div>
                                    </div>                                    
                                    <div class="mt-4">
                                        <label>Brand Name</label>
                                        <input id="brandname" name="brandname" type="text" class="input w-full border border-dark-3 bg-gray-100 mt-2" placeholder="Input Brand Name">
                                    </div>
                                    <div class="mt-4">
                                        <label>Pack Size</label>
                                        <input id="packsize" name="packsize" type="text" class="input w-full border border-dark-3 bg-gray-100 mt-2" placeholder="Input Pack Size">
                                    </div>
                                    <div class="mt-4">
                                        <input id="dataentryby" name="dataentryby" type="hidden" class="input w-full border border-dark-3 bg-gray-100 cursor-not-allowed mt-2" placeholder="Product Group" value="<?php echo e(Auth::User()->name); ?>">
                                    </div>
                                <?php if(Auth::User()->role == 'Warehouse Manager'): ?>
                                    <button type="submit" class="button w-20 bg-theme-1 text-white mt-3">Save</button>
                                    <?php else: ?>
                                    <button class="button w-20 bg-theme-2 text-white mt-3" disabled>Save</button>
                                <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </form>
                    </div>
                    <!-- END: Display Information -->
                </div>
                <div class="intro-y col-span-12 lg:col-span-6 relative inset-0 w-full min-h-screen lg:fixed lg:w-full/12" style="height: 532px;">
                    <!-- BEGIN: Table Section Information -->
                    <div class="intro-y box lg:mt-5" style="overflow: auto; height: 532px">
                        <div class="flex items-center p-5 border-b border-gray-200 dark:border-dark-5">
                            <h2 class="font-medium text-base mr-auto">
                                Products
                            </h2>
                        </div>
                        <div class="p-5" style="width: 67%">

                        </div>                         
                        <table class="table">
                        <thead>
                            <tr class="bg-gray-700 dark:bg-dark-1 text-white">
                                <th class="whitespace-no-wrap">Product Type</th>
                                <th class="whitespace-no-wrap">Manufacturer</th>
                                <th class="whitespace-no-wrap">Brand Name</th>
                                <th class="whitespace-no-wrap">Pack-Size</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $producttable; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productinfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="border-b dark:border-dark-5"><?php echo e($productinfo->producttype); ?></td>
                                <td class="border-b dark:border-dark-5"><?php echo e($productinfo->manufacturer); ?></td>
                                <td class="border-b dark:border-dark-5 font-bold"><?php echo e($productinfo->brandname); ?></td>
                                <td class="border-b dark:border-dark-5"><?php echo e($productinfo->packsize); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                    <!-- END: Table Section Information -->
                </div>            
            </div>
        </div>
        <!-- END: Content -->
        <!-- JQUERY -->

<script type="text/javascript">
        $(document).ready(function(){
            $('#producttype').change(function(){
                var producttype = this.value;
            $("#manufacturer").html('');
            $.ajax({
                url:"<?php echo e(url('get-manufacturer-by-producttype')); ?>",
                type: "POST",
                data: {
                producttype: producttype,
                _token: '<?php echo e(csrf_token()); ?>' 
                },
                dataType : 'json',
                success: function(result){ 
                    $('#manufacturer').html('<option  style="height: 40px" value="">Select Manufacturer</option>'); 
                    $.each(result.manufacturer,function(key,value){
                    $("#manufacturer").append('<option value="'+value.manufacturer+'">'+value.manufacturer+'</option>');
                    });
                }
            });        
        });
});

<?php if(Session::has('message')): ?>
 var type = "<?php echo e(Session::get('alert-type','info')); ?>"
 switch(type){
    case 'info':
    toastr.info(" <?php echo e(Session::get('message')); ?> ");
    break;
    case 'success':
    toastr.success(" <?php echo e(Session::get('message')); ?> ");
    break;
    case 'warning':
    toastr.warning(" <?php echo e(Session::get('message')); ?> ");
    break;
    case 'error':
    toastr.error(" <?php echo e(Session::get('message')); ?> ");
    break; 
 }
 <?php endif; ?> 
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('warehouse.warehouse_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\warehousemanager\resources\views/warehouse/createproduct.blade.php ENDPATH**/ ?>