<html>
<head>
    <meta charset="utf-8">
    <title>About</title>
</head>
<body>
    <h1>About Page</h1>

    <p>This is the regular about page. We had some hiccups but we back again Ma Negg</p>
    <a href="{{ route('test.page') }}">Test Page</a>

</body>
</html>