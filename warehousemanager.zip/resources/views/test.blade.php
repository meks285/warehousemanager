<html>
<head>
    <meta charset="utf-8">
    <title>Test</title>
</head>
<body>
    <h1>Test Page</h1>

    <p>This is the regular test page</p>
    <a href="{{ route('contact.page') }}">Contact Page</a>

</body>
</html>